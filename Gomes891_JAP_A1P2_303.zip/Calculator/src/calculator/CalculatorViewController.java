/*
 * File Name: CalculatorModel.java
 * Author: Aria Gomes, 040878659 
 * Course: CST8221 - JAP, Lab Section: 303
 * Assignment: 1 Part 2
 * Date: March 6, 2019
 * Professor: Svillan Ranev
 * Purpose: This class gives instructions to place each component in the correct position with the correct size, color and parameters
 */
package calculator;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
	
/** 
 * @author Aria Gomes
 * @version 2
 * @see Controller
 * @since 1.8.0_144
 */

public class CalculatorViewController extends JPanel 
{
	private static final long serialVersionUID = -1358422722986703478L;
	/**
	 *  the calculator display1 field reference
	 */
	private JTextField display1; 
	/**
	 *  the calculator display2 field reference
	 */
    private JTextField display2; 
    /**
     * the mode/error display label reference
     */
    private JLabel error; 
    /**
     *  the decimal point (dot) button reference
     */
    private JButton dotButton;
    /**
     * reference to container for alphabetical hex buttons
     */
    private JButton[] hexButtons; 
    /**
     * reference to the backspace button
     */
    private JButton backspaceButton;
    /**
     * reference to Controller handler
     */
    private Controller handler;
    /**
     * reference to JPanel containing the middle calculator components
     */
    private JPanel midPanel;
    /**
     * reference to JPanel containing the main calculator components
     */
    private JPanel main;
    /**
     * reference to JPanel containing the top calculator components
     */
    private JPanel topRow;													// Declaration of Objects used in default constructor
    /**
     * reference to JPanel containing text
     */
    private JPanel text;
    /**
     * reference to the JPanel holding the backspace button
     */
    private JPanel backspace;
    /**
     * reference to JPanel holding the mode Label
     */
    private JPanel mode;
    /**
     * reference to JPanel holding the error Label
     */
    private JPanel errorPanel;
    /**
     * reference to Box Object
     */
    private Box box;
    /**
     * reference to buttonGroup Object
     */
    private ButtonGroup groupButtons;
    /**
     * reference to hexadecimal checkbox
     */
    protected JCheckBox hex;
    /**
     * reference to single decimal radio button
     */
    private JRadioButton decimal1;
    /**
     * reference to double decimal radio button
     */
    private JRadioButton decimal2;
    /**
     * reference to scientific radio button
     */
    private JRadioButton scientific;
    /**
     * reference to JPanel containing the calculator keypad
     */
    private JPanel keypad;
    /**
     * reference to first addition JButton
     */
    private JButton plus;
    /**
     * reference to first subtraction JButton
     */
    private JButton minus;
    /**
     * reference to JPanel containing calculator components north of the keypad
     */
    private JPanel northKeypad; 
    /**
     * reference to JPanel containing calculator components south of the keypad
     */
    private JPanel southKeypad;
    /**
     * reference to first multiplication JButton
     */
    private JButton multiply;
    /**
     * reference to first division JButton
     */
    private JButton divide;
    /**
     * reference to JPanel containing all arithmetic operator JButtons
     */
    private JPanel arithmetic;
    /**
     * reference to key JButton
     */
    private JButton key;
    /**
     * reference to clear JButton
     */
    private JButton clear;
    /**
     * reference to equal JButton
     */
    private JButton equal;
    /**
     * reference to second multiply JButton
     */
    private JButton multiply1;
    /**
     * reference to second divide JButton
     */
    private JButton divide1;
    /**
     * reference to second addition JButton
     */
    private JButton plus1;
    /**
     * reference to second subtraction JButton
     */
    private JButton minus1;
    
    /*{@value} Holds the text to be displayed in each key on the keypad */
    private static final String[] KEY_NUMS = {"A", "B", "C", "D", "E", "F", "7", "8", "9", "4", "5", "6", "1", "2", "3", ".", "0", "\u00B1"}; // Array to be used in creating keypad
    // CalculatorModel reference
    CalculatorModel model = new CalculatorModel(); 
	
    public CalculatorViewController() 
    {  
    	// Sets sizing and border for overall calculator
    	this.setLayout(new BorderLayout());
    	this.setSize(380, 540);
    	this.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.BLACK));
    	
    	// Sets the action listener 
    	handler = new Controller(new CalculatorModel());
    	
    	//Sets the midPanel to be used for keypad and operator buttons
    	midPanel = new JPanel(new BorderLayout());
    	
	    // Creates the main panel to be used
	    main = new JPanel(new BorderLayout());
	    
	    // Creates the foundation elements of the top row
	    topRow = new JPanel(new BorderLayout());
	    
	    // Creates a panel to hold the two display elements
	    text = new JPanel(new BorderLayout());
	    
	    // Creates a panel to hold the backspace button
	    backspace = new JPanel(new BorderLayout());
	    
	    // Creates the foundation elements of the mode panel
	    mode = new JPanel(new BorderLayout());
	    
	    // Creates a box to hold the check box and radio buttons
	    box = Box.createHorizontalBox();
	    
	    // Creates a group to ensure only one of hex or radio buttons are toggled
	    groupButtons = new ButtonGroup();
	    
	    // Creates the hex check box
	    hex = new JCheckBox("HEX");
	    
	    // Creates the single precision decimal radio button
	    decimal1 = new JRadioButton(".0");
	    
	    // Creates the double precision decimal radio button
	    decimal2 = new JRadioButton(".00");
	    
	    // Creates the scientific notation decimal radio button
	    scientific = new JRadioButton("SCI");
	    
	    // Creates the foundation elements of the keypad
	    keypad = new JPanel(new BorderLayout());
	    
	    // Creates the addition button
	    plus = createButton("+", "+", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates the subtraction button
	    minus = createButton("-", "-", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates the backspace button with unicode
	    backspaceButton = createButton("\u21D0", "\u21D0", Color.BLACK, Color.YELLOW, handler);
	    
	    // North keypad operator buttons panel
	    northKeypad = new JPanel( new GridLayout(1 , 4, 10, 0));
	    
	    // North keypad operator buttons panel
	    southKeypad = new JPanel( new GridLayout(1 , 4, 10, 0));
	    
	    // Creates multiplication button
	    multiply = createButton("*", "*", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates division button
	    divide = createButton("/", "/", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates a panel that holds the arithmetic buttons
	    arithmetic = new JPanel(new GridLayout(0, 3, 3, 3));
	    
	    // Creates clear button
	    clear = createButton("C", "clear", Color.BLACK, Color.RED, handler);
	    
	    // Creates equal button
	    equal = createButton("=", "=", Color.BLACK, Color.YELLOW, handler);
	    
	    // Creates the addition button
	    plus1 = createButton("+", "+", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates the subtraction button
	    minus1 = createButton("-", "-", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates multiplication button
	    multiply1 = createButton("*", "*", Color.BLACK, Color.CYAN, handler);
	    
	    // Creates division button
	    divide1 = createButton("/", "/", Color.BLACK, Color.CYAN, handler);
	    
	    //Error Panel Reference
	    errorPanel = new JPanel();
	    
	    
	    // Begin top panel
	    // Mode/Error label
	    error = new JLabel("F");
	    errorPanel.setPreferredSize(new Dimension(55,0));
        error.setFont(new Font(null, Font.BOLD, 20));
	    error.setHorizontalAlignment(SwingConstants.CENTER);
	    errorPanel.setBackground(Color.YELLOW);
	    errorPanel.add(error, BorderLayout.SOUTH);
	    error.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
	    errorPanel.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 5, Color.BLACK));
	    topRow.add(errorPanel, BorderLayout.BEFORE_LINE_BEGINS);
	    
	    // Display Text boxes
	    display1 = new JTextField(null, 14);
	    display1.setPreferredSize(new Dimension(0, 30));
	    display1.setHorizontalAlignment(SwingConstants.RIGHT);
	    display1.setBorder(BorderFactory.createEmptyBorder());
	    display1.setEditable(false);
	    text.add(display1, BorderLayout.PAGE_START);
	    //Display 2
	    display2 = new JTextField("0.0", 14);
	    display2.setPreferredSize(new Dimension(0, 30));
	    display2.setHorizontalAlignment(SwingConstants.RIGHT);
	    display2.setBorder(BorderFactory.createEmptyBorder());
	    display2.setEditable(false);
	    text.add(display2, BorderLayout.PAGE_END);
	    topRow.add(text);
	    
	    // Creates the backspace button
	    backspaceButton.setPreferredSize(new Dimension(52, 55));
	    backspaceButton.setOpaque(false);
	    backspaceButton.setContentAreaFilled(false);
	    backspaceButton.setBorder(BorderFactory.createMatteBorder(0, 5, 0, 1, Color.BLACK));
	    backspaceButton.setToolTipText("Backspace (Alt-B)");
	    backspaceButton.setMnemonic('b');
	    
	    // Adds the backspace button to the backspace panel
	    backspace.add(backspaceButton);
	    backspace.setBackground(Color.YELLOW);
	    
	    // Adds the backspace panel to the top row
	    topRow.add(backspace, BorderLayout.LINE_END);
	    topRow.setBackground(Color.YELLOW);
	    
	    // Begin mode panel
	    hex.setBackground(Color.GREEN);
	    groupButtons.add(hex);
	    box.setBackground(Color.BLACK);
	    box.setBorder(BorderFactory.createMatteBorder(10, 2, 10, 2, Color.BLACK));
	    box.add(hex, BorderLayout.LINE_START);
	    hex.addActionListener(handler);

	    // Radio button group
	    // Adds spacing element to the box
	    box.add(Box.createHorizontalGlue());
	    
	    // Adds decimal 1 to the button group and sets visual elements
	    groupButtons.add(decimal1);
	    decimal1.setBackground(Color.YELLOW);
	    decimal1.addActionListener(handler);
	    box.add(decimal1);
	    
	    // Adds decimal 2 to the button group and sets visual elements
	    groupButtons.add(decimal2);
	    decimal2.setBackground(Color.YELLOW);
	    decimal2.addActionListener(handler);
	    // Sets decimal 2 as default selection on launch
	    decimal2.setSelected(true);
	    box.add(decimal2);

	    // Adds scientific to the button group and sets visual elements
	    groupButtons.add(scientific);
	    scientific.setBackground(Color.YELLOW);
	    scientific.addActionListener(handler);
	    box.add(scientific);
	    
	    // Adds mode panel to top row
	    mode.add(box, BorderLayout.PAGE_START);
	    mode.setBorder(BorderFactory.createEmptyBorder());
	    mode.setBackground(Color.BLACK);
	    topRow.add(mode, BorderLayout.PAGE_END);
	    
	    //Creates the midpanel
	    midPanel.add(keypad, BorderLayout.CENTER);
	    midPanel.add(northKeypad, BorderLayout.NORTH);
	    midPanel.add(southKeypad, BorderLayout.SOUTH);
	    
	    // Adds top row to main panel
	    main.add(topRow, BorderLayout.PAGE_START);
	    
	    // Begin arithmetic panel
	    // Array to hold hex buttons
	    hexButtons = new JButton[6];
	    // Creates arithmetic buttons (digits and hex) within keypad
	    for(int i = 0; i < KEY_NUMS.length; i++) 
	    {
	    	if(KEY_NUMS[i].matches("[A-Z]")) 
	    	{
	    		// Creates hex buttons
	    		hexButtons[i] = createButton(KEY_NUMS[i], KEY_NUMS[i], Color.BLACK, Color.BLUE, handler);
	    		hexButtons[i].setEnabled(false);
	    		arithmetic.add(hexButtons[i]);
	    	}
	    	else if(KEY_NUMS[i].matches("\\d+")) 
	    	{
	    		// Creates digit buttons
	    		key = createButton(KEY_NUMS[i], KEY_NUMS[i], Color.BLACK, Color.BLUE, handler);
	    		arithmetic.add(key);
	    	}
	    	else if(KEY_NUMS[i].matches("[.]")) 
	    	{ 
	    		// Creates the dot button
	    		dotButton = createButton(KEY_NUMS[i], KEY_NUMS[i], Color.BLACK, Color.MAGENTA, handler);
	    		arithmetic.add(dotButton);
	    	}
	    	else 
	    	{
	    		// Creates the +- button
	    		key = createButton(KEY_NUMS[i], KEY_NUMS[i], Color.BLACK, Color.MAGENTA, handler);
	    		arithmetic.add(key);
	    	}
	    }
	    arithmetic.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.WHITE));
	    
	    // Adds addition, subtraction, multiplication and division buttons to the north side of keypad
	    northKeypad.add(plus, BorderLayout.PAGE_START);
	    northKeypad.add(minus, BorderLayout.PAGE_START);
	    northKeypad.add(multiply, BorderLayout.PAGE_START);
	    northKeypad.add(divide, BorderLayout.PAGE_START);
	    northKeypad.setBackground(Color.BLACK);
	    
	    // Adds addition, subtraction, multiplication and division buttons to the south side of keypad
	    southKeypad.add(multiply1, BorderLayout.PAGE_START);
	    southKeypad.add(divide1, BorderLayout.PAGE_START);
	    southKeypad.add(plus1, BorderLayout.PAGE_START);
	    southKeypad.add(minus1, BorderLayout.PAGE_START);
	    southKeypad.setBackground(Color.BLACK);
	    
	    // Sets the clear and equal dimension borders and background
	    clear.setPreferredSize(new Dimension(55, 0));
	    clear.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 5, Color.BLACK));
	    equal.setPreferredSize(new Dimension(55, 0));
	    equal.setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.BLACK));
	    
	    // Adds clear and equal to keypad
	    main.add(clear, BorderLayout.WEST);
	    main.add(equal, BorderLayout.EAST);
 
	    // Adds the components of the keypad to the main panel
	    keypad.add(southKeypad, BorderLayout.SOUTH);
	    keypad.add(arithmetic, BorderLayout.CENTER);
	    keypad.add(northKeypad, BorderLayout.NORTH);
	    main.add(midPanel);
	    
	    // Adds main panel to calculator frame
	    this.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.BLACK)); // Gives the whole panel a 5 pixel border
	    this.add(main);
	    setVisible(true);// makes the panel visible 
    }
    

    /**
     * Provides a way to quickly define and create buttons of similar action
     * 
     * @author Aria Gomes
     * @param	text : String - the text to be displayed in the key
     * @param	ac : String	- the action command to be returned by the button
     * @param	fg : Color - the color of the foreground of the button
     * @param	bg : Color - the color of the background of the button
     * @param	handler : ActionListener - the listener of the action returned by the button
     * 
     * @return	JButton - returns the button created by this method
     */
    private JButton createButton(String text, String ac, Color fg, Color bg, ActionListener handler)
    {
    	// Creates the button with the passed text argument
        JButton button = new JButton(text);
        
        if(ac != null) 
        	button.setActionCommand(ac);
        
        // Sets colors and fonts of button
        button.setBackground(bg);
        button.setForeground(fg);
        
        if(ac.equalsIgnoreCase("clear")) //Special casses for C and Equal buttons because the font is too large
        	button.setFont(new Font(null, Font.BOLD, 15));
        else if(text.equalsIgnoreCase("="))
        	button.setFont(new Font(null, Font.BOLD, 12));
        else if(text.equalsIgnoreCase("+"))
        	button.setFont(new Font(null, Font.BOLD, 13));
        else
        	button.setFont(new Font(null, Font.BOLD, 20));
        
        button.addActionListener(handler);
        return button;
    }
    
    /** 
	 * @author Aria Gomes
	 * @version 2
	 * @since 1.8.0_144
	 */
	
	private class Controller implements ActionListener 
	{
		
		CalculatorModel model; // an implementation of the CalculatorModel class to be used in this class
		
		/**
		 * A constructor to create the model 
		 * 
		 * @param model the CalculatorModel that is used 
		 */
		public Controller (CalculatorModel model) {
			this.model = model;
		}
		
		/**
		 * This is an action listener and listens for the actions that are performed.
		 * @author Aria Gomes
		 * @param event The event that was performed.
		 */
		
		public void actionPerformed(ActionEvent event) {
			
			boolean errors = false;
			
			// switch case for all the buttons that can be pressed
			switch (event.getActionCommand()) {
			// all the numbers
			case "1":
			case "2":
			case "3":
			case "4":
			case "5":
			case "6":
			case "7":
			case "8":
			case "9":
			case "0":
			case "A":
			case "B":
			case "C":
			case "D":
			case "E":
			case "F":
				// make sure no errors were done 
				if (!model.getErrorMode()) {
					
					// enable the backspace button if it was disabled
					if (!backspace.isEnabled())
						display2.setText("");
					backspace.setEnabled(true);
					
					// if the operational mode is not 1 reset the Error
					if (model.getOperationalMode() != 1)
						resetError();
					
					// change the display with the characters
					if (display2.getText().equals("0.0")) {
						display2.setText(event.getActionCommand());
					} else {
						display2.setText(display2.getText().concat(event.getActionCommand()));
					}
					
					// change the error if one has occured
					if (model.getErrorMode())
						errors = true;
				}
				break;
			// all the arithemtic operators
			case "*":
			case "/":
			case "-":
			case "+":
				if (!model.getErrorMode()) {
					
					// reenable the backsapce button
					backspace.setEnabled(true);
					
					// assign the 1st operand and set the text for the dislays
					model.setOperand1(display2.getText());
					display1.setText(display2.getText().concat(" " + event.getActionCommand()));
					display2.setText("");
					
					// assign the arithmetic character
					model.setArithmetic(event.getActionCommand());
					
					if (model.getErrorMode())
						errors = true;
				}
				break;
			// the equal button
			case "=":
				// set the displays 
				if (display2.getText().equals(""))
					model.setOperand2(model.getOperand1());
				else if (display1.getText().equals(""))
					model.setOperand1(display2.getText());
				else 
					model.setOperand2(display2.getText());
				display1.setText("");
				
				// disable the backspace button
				backspace.setEnabled(false);
				
				// do the operations
				display2.setText(model.operation());
				
				if (model.getErrorMode())
					errors = true;
				
				break;
			// the dot button
			case ".":
				if (!model.getErrorMode()) {
					// add the dot to the display
					display2.setText(display2.getText().concat("."));
				}
				break;
			// the +/- button
			case "\u00b1":
				if (!model.getErrorMode()) {
					// add or take off the +/- on the number
					if (display2.getText().startsWith("-")) {
						display2.setText(display2.getText().substring(1));
					} else {
						display2.setText("-".concat(display2.getText()));
					}
					if (model.getErrorMode()) {
						errors = true;
					}
				}
				break;
			// the backspace button
			case "\u21d0":
				if (!model.getErrorMode()) {
					
					// if the display is greater than > 1 
					if (display2.getText().length() >= 1) { 
							
						// subtract the display
						display2.setText(display2.getText().substring(0, display2.getText().length() - 1)); 
						
						if (display2.getText().length() == 1 && display2.getText().contains("-")) {
							setDisplays("", "0.0"); 
							model.reset();
						}
					} else { // otherwise the display is 0.0
						setDisplays("", "0.0"); 
						model.reset();
					}
				}
					
				if (model.getErrorMode()) {
					errors = true;
				}
				break;
			// the clear button
			case "clear":
				// set the display to nothing, and reset the operands
				setDisplays("", "0.0");
				model.reset();
				backspace.setEnabled(true);
				model.setErrorState(false);
				break;
			// the .0 option
			case ".0":
				// set the operational mode 
				model.setOperationalMode(0);
				model.setPrecision(0);
				
				// reset the displays
				setDisplays("", "0.0");
				
				// turn off hex buttons
				if (hexButtons[0].isEnabled()) {
					for (int i = 0; i < hexButtons.length; i++)
						hexButtons[i].setEnabled(false);
					dotButton.setEnabled(true);
					
					// change the error button
					error.setText("F");
					errorPanel.setBackground(Color.YELLOW);
				}
				break;
			// the .00 option
			case ".00":
				// set the operational mode
				model.setOperationalMode(0);
				model.setPrecision(1);
				
				// reset the displays
				setDisplays("", "0.00");
				
				// turn off the hexbuttons
				if (hexButtons[0].isEnabled()) {
					for (int i = 0; i < hexButtons.length; i++)
						hexButtons[i].setEnabled(false);
					dotButton.setEnabled(true);
					
					// change the error button
					error.setText("F");
					errorPanel.setBackground(Color.YELLOW);
				}
				break;
			// the sci option
			case "SCI":
				// set the operational mode
				model.setOperationalMode(0);
				model.setPrecision(2);
				
				// reset the displays
				setDisplays("", "0.00");
				
				// turn off the hex buttons
				if (hexButtons[0].isEnabled()) {
					for (int i = 0; i < hexButtons.length; i++)
						hexButtons[i].setEnabled(false);
					dotButton.setEnabled(true);
					
					// change the error button
					error.setText("F");
					errorPanel.setBackground(Color.YELLOW);
				}
				break;
			// the hex button
			case "HEX":
				
				// reset the displays
				setDisplays("", "");
				
				// set the hexbuttons to enabled and disable the dotbutton, change the operational mode
				for (int i = 0; i < hexButtons.length; i++)
					hexButtons[i].setEnabled(true);
				dotButton.setEnabled(false);
				model.setOperationalMode(1);
					
				// change the error button
				error.setText("H");
				errorPanel.setBackground(Color.GREEN);
				
				break;
				
			}
			
			// if there was an error set the error button
			if (errors) {
				error.setText("E");
				errorPanel.setBackground(Color.RED);
			}
		}
		
		/**
		 * Resets the display
		 * @param disp1 What display 1 becomes
		 * @param disp2 What display 2 becomes
		 */
		private void setDisplays(String disp1, String disp2) {
			display1.setText(disp1);
			display2.setText(disp2);
		}
		
		/**
		 * Reset the error field
		 */
		private void resetError() {
			error.setText("F");
			errorPanel.setBackground(Color.YELLOW);
		}
	}
}