/*
 * File Name: CalculatorModel.java
 * Author: Aria Gomes, 040878659 
 * Course: CST8221 - JAP, Lab Section: 303
 * Assignment: 1 Part 2
 * Date: March 6, 2019
 * Professor: Svillan Ranev
 * Purpose: This is the Main class of the Calculator. Calls the Splash screen, view controller, and Model as well as setting dimensions for the swing Window
 */

package calculator;
import java.awt.Dimension;
import java.awt.EventQueue;
import javax.swing.JFrame;

/** 
 * @author Aria Gomes
 * @version 2
 * @since 1.8.0_144
 */
public class Calculator
{
	public static void main(String args[])
	{
		/**
		 *  Dimension of the main calculator Frame
		 */
		Dimension calcSize = new Dimension(340, 500); 
		/**
		 *  Declaration of reference objects needed to launch and manipulate the panels/frames
		 */
		CalculatorSplashScreen splash = new CalculatorSplashScreen(); 
		
		splash.showSplash(); // launches the splash screen
	EventQueue.invokeLater(new Runnable() 
	{
		public void run() 
		{
			//Show the Calculator
			JFrame calcFrame = new JFrame("Calculator - Aria Gomes"); // Creates the main calculator frame with a custom title
			calcFrame.setMinimumSize(calcSize); // sets the dimension for the frame
			calcFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // gives the frame operation to execute on close
			calcFrame.setLocationByPlatform(true); // sets the location of the frame by the platform launched on
			calcFrame.setLocationRelativeTo(null); // centers the frame on the screen
			CalculatorViewController cvc = new CalculatorViewController();
			calcFrame.setContentPane(cvc);
			calcFrame.setVisible(true); // Finally shows the frame once everything has been executed
			
		}
	});
}
}